from soil import sample


def main():
    moisture = sample()
    print(f"Moisture is {moisture}%")


main()
